export default function NewWorkflowLayout({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return children;
  } 
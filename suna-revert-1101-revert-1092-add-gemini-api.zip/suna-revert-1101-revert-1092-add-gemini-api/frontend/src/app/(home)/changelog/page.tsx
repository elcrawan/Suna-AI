import { Changelog } from "@/components/home/sections/changelog";

export default function ChangelogPage() {
  return (
    <section id="changelog">
      <Changelog />
    </section>
  );
}